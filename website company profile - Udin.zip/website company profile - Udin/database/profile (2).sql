-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Mar 2021 pada 07.24
-- Versi server: 10.4.13-MariaDB
-- Versi PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `profile`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_about`
--

CREATE TABLE `tbl_about` (
  `id_about` int(11) NOT NULL,
  `about` text DEFAULT NULL,
  `visi_misi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_about`
--

INSERT INTO `tbl_about` (`id_about`, `about`, `visi_misi`) VALUES
(1, '<p>Jericho dibangun pada tahun 2019 oleh sekelompok anak IT yang ingin membuat sebuah perusahaan IT yang melayani pembuatan web dan domain. asal mula jericho dari suatu pengalaman hidup pribadi masing-masing orang yang ingin mendirikan perusahaan IT,dari nol sampai sekarang jericho terdapat banyak kesulitan yang dialami.Mulai dari kurangnya modal , dihina dan dicaci maki, sampai pernah berfikir untuk menyerah, kini jericho telah membuktikan kepada dunia bahwa jericho bisa berdiri sampai sekarang ini untuk melayani masyarakat didunia. test</p>', '<p><strong>Visi JERICHO</strong></p><p>Menjadikan perusahaan Jericho sebagai perusahaan yang memajukan komunikasi dan informasi digital, unggul, serta dikenal di seluruh dunia pada era 4.0</p><p><strong>Misi JERICHO&nbsp;</strong></p><p>1. Menjadikan perusahaan Jericho menjadi perusahaan yang unggul di dunia</p><p>2. Menjadikan para pelajar&nbsp;smk menjadi siswa yang mampu mengembangkan sarana komukasi dan informasi digital pada era 4.0.</p><p>&nbsp;</p>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_artikel`
--

CREATE TABLE `tbl_artikel` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_artikel`
--

INSERT INTO `tbl_artikel` (`id`, `judul`, `isi`, `tanggal`, `foto`, `id_kategori`) VALUES
(12, 'Seminar di Sekolah Smk Yaj Depok ', '<p>Seminar ini bertujuan untuk memberikan edukasi seputar dunia IT kepada siswa/i SMK Yaj khususnya jurusan RPL untuk memberikan pengalaman kerja dilapangan.</p>', '2019-08-24', '20210225-pelantikan-dan-pengukuhan-pmr-smk-yaj-depok.jpg', 10),
(13, 'Kegitan bootcamp membuat website ', '<p>Kegiatan bootcamp ini bertujuan untuk melatih orang orang yang ingin belajar atau mendalami ilmu membuat suatu website&nbsp;</p>', '2020-01-10', '20210226-kegitan-bootcamp-membuat-website-.jpg', 3),
(14, 'workshop', '<p>Kegiatan workshop Praktek kerja lapangan di SMK YAJ&nbsp; Pada masa pandemi&nbsp; agar siswa/i smk yaj mempunyai pengalaman kerja&nbsp;</p>', '2020-01-10', '20210214-belajar-sehari-di-luar-kelas.jpeg', 10),
(19, 'Loker IT', '<p>Deskripsi Pekerjaan</p><p>Bergabunglah dengan kami, jika Anda:</p><p>1. Aktif, berjiwa muda, dan semangat</p><p><strong>2. Menguasai PHP Native &amp; Laravel</strong></p><p><strong>3. Lebih disukai mempunyai basic react &amp; angular</strong></p><p>3. Hobi / gemar membuat website</p><p>4.&nbsp;<strong>Mempunyai pengalaman sebagai web programmer (minimal 1 - 2 tahun)</strong></p><p>5. Pendidikan terakhir minimal D3/S1 Ilmu Komputer atau Teknik Informatika</p><p>6. Komunikasi baik</p><p>Deskripsi Pekerjaan:</p><p>1. Maintenance website perusahaan</p><p>2. Memperbarui fitur web</p><p>3. Mengirimkan report tepat waktu</p><p>4. Menjalin kerjasama yang baik antar team</p>', '2021-03-03', '20210303-loker-it.jpg', 13),
(20, 'Office boy', '<p>eskripsi Pekerjaan</p><p><strong>KUALIFIKASI:</strong></p><ul><li>Usia maksimal 35 tahun</li><li>Pendidikan minimal SMU atau sederajat&nbsp;</li><li>Diutamakan memiliki pengalaman di bidang cleaning service / officeboy / officegirl minimal 3 tahun&nbsp;</li><li>Jujur, pekerja keras dan bertanggungjawab</li><li>Giat, dapat bekerja secara mandiri maupun di dalam team serta mampu bekerja di bawah tekanan</li></ul><p><strong>TANGGUNG JAWAB:</strong></p><ul><li>Bertanggung jawab atas kebersihan dan kerapihan showroom, ruang kerja pimpinan, ruang kantor, pantry dan sekitarnya (menyapu, pel, lap kaca, poles marmer, dlll).</li><li>Memeriksa kebersihan dan membuang sampah setiap hari sebelum pulang kerja.</li><li>Menjaga dan merawat perlengkapan / peralatan yang digunakan seperti : gelas, piring, sendok, garpu, sapu, vacuum cleaner, kain lap, dll.</li><li>Membersihkan barang-barang di Showroom&nbsp;dengan hati-hati setiap hari.</li><li>Melayani customer dengan standar yang telah ditetapkan oleh perusahaan</li></ul>', '2021-03-03', '20210303-office-boy.jpg', 13),
(21, 'Administrasi ', '<p>Deskripsi Pekerjaan</p><p>Kualifikasi:</p><ul><li>Pendidikan minimal SMA/ SMK sederajat.</li><li>Mampu mengoperasikan komputer (Ms. Office, browsing, aplikasi chatting, facebook, gmail, google docs, dll).</li><li>Mampu menggunakan Android Phone/ Tablet (bisa menggunakan aplikasi line, instagram, atau whatsapp).</li><li>Tidak sedang kuliah/bekerja/berbisnis.</li><li>Wajib memiliki motor sendiri.</li><li>Familiar terhadap forum online shop dan media sosial.</li><li>Komunikatif dalam melayani customer secara online.</li><li>Jujur, disiplin, rajin, teliti, ramah dan memiliki minat kerja yang tinggi.</li><li>Memiliki pengalaman kerja minimal 1 tahun di bidangnya.</li></ul><p><br />Deskripsi Pekerjaan:</p><ul><li>Melayani (menjawab) pertanyaan/ chat on line dari konsumen baik dari marketplace maupun pesan teks.</li><li>Bertindak sebagai customer service untuk menerima dan menanggapi keluhan apabila ada.</li><li>Mengelolah penjualan website: layanan dan harga website</li><li>Menerima dan memproses pesanan (orderan) dari website marketplace.</li><li>Packing dan delivery untuk memastikan aplikasi yang dipesan&nbsp;diterima oleh konsumen.</li><li>Quality control.</li><li>Membuat laporan penjualan.</li></ul>', '2021-03-03', '20210303-administrasi-.png', 13),
(22, 'Praktek Kerja 2021 ', '<p>Syarat peserta praktek kerja :</p><p>1. Menerapkan 3M( Memcuci tangan, Menggunakan masker, Menjaga Jarak)</p><p>Syarat pengajual praktek kerja :</p><p>1. Membawa surat pengajuan Praktek Kerja dari sekolah atau Universitas terkait</p><p>2. Membuat Proposal Praktek Kerja</p><p>3. Mengisi biodata peserta prak</p>', '2021-03-04', '20210304-praktek-kerja-2021-.jpg', 14);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kategori_artikel`
--

CREATE TABLE `tbl_kategori_artikel` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_kategori_artikel`
--

INSERT INTO `tbl_kategori_artikel` (`id`, `nama_kategori`) VALUES
(3, 'Bootcamp'),
(10, 'Seminar'),
(13, 'Info Loker'),
(14, 'Praktek Kerja');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pengguna`
--

CREATE TABLE `tbl_pengguna` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_pengguna`
--

INSERT INTO `tbl_pengguna` (`id`, `nama`, `username`, `password`, `foto`) VALUES
(3, 'Administrator', 'admin', '$2y$10$9uAKnax9/7HoMVtMFWDUEe6GhtWdq5SIn75AWwHnYboKctXCfybVG', 'administrator.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pesan`
--

CREATE TABLE `tbl_pesan` (
  `id_pesan` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `notlp` int(20) NOT NULL,
  `pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_pesan`
--

INSERT INTO `tbl_pesan` (`id_pesan`, `nama`, `email`, `notlp`, `pesan`) VALUES
(4, 'test', 'sss333@gmail.com', 24141421, 'as'),
(6, 'test', 'sss333@gmail.com', 24141421, 'test'),
(7, 'miftah', 'sss333@gmail.com', 24141421, 'test'),
(8, 'testttt', 'tesstt@mail.com', 2147483647, 'testung'),
(11, 'tesete', 'etsets@adsa.bo', 321412, 'tererrerererer'),
(12, 'asdadasd', 'adsada@adsa.co', 442141, 'affafa'),
(13, 'fufdfaffg', 'srsrsrss@dfdg', 778288, 'gggagag'),
(14, 'asdsad', 'dasdasd@aeda', 0, 'adawd'),
(15, 'asdasdsa', 'dasdsad@sdasd', 0, 'adw adawa'),
(16, 'nama', 'email@ads', 0, 'pesab'),
(17, 'nama', 'sadsad@sad', 0, 'asdsad'),
(18, 'anma', 'anma@asda', 0, '12312aw'),
(19, 'udin', 'udin@gmail.com', 2147483647, 'pesen bwang'),
(20, 'test', 'udin@gmail.com', 2147483647, 'test'),
(21, 'udin', 'udin@gmail.com', 2147483647, '11111111111111111111'),
(22, 'bams official', 'informasi@bams.com', 12345678, '12345678'),
(23, 'tatatatatatatt', 'tatatata@gmail.com', 12354567, 'tatatatattatatatta');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_about`
--
ALTER TABLE `tbl_about`
  ADD PRIMARY KEY (`id_about`);

--
-- Indeks untuk tabel `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `foto` (`foto`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `tbl_kategori_artikel`
--
ALTER TABLE `tbl_kategori_artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_pengguna`
--
ALTER TABLE `tbl_pengguna`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_pesan`
--
ALTER TABLE `tbl_pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_about`
--
ALTER TABLE `tbl_about`
  MODIFY `id_about` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `tbl_kategori_artikel`
--
ALTER TABLE `tbl_kategori_artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `tbl_pengguna`
--
ALTER TABLE `tbl_pengguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbl_pesan`
--
ALTER TABLE `tbl_pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
  ADD CONSTRAINT `tbl_artikel_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `tbl_kategori_artikel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
