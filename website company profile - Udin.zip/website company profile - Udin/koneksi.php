<?php 
session_start();

$koneksi = mysqli_connect('localhost', 'root', '', 'profile') or die('error db!');

?>