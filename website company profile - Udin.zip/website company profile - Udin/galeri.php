<?php 

require_once 'koneksi.php';


$query = mysqli_query($koneksi, "SELECT * FROM tbl_artikel  order by id desc ");
$artikel = mysqli_fetch_assoc($query);
$aktif = 'galeri'; 
?>


		<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link rel="icon" type="icon" href="img/g.png"> 
	  <link rel="stylesheet" href="resources/fonts/stylesheet.css">
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
        .slider h3,
        .slider h5,
        .clients h3 {
          text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
      }
      .parallax-container {
        height: 240px;
      }
      .parallax img{
        filter: grayscale(1);
        opacity: 0.5 !important;
      }
      </style>
      <title>Jericho</title>
    </head>

    <body>
      
      <!-- Navbar -->
       <div class="navbar-fixed">
    <nav class="blue darken-2">
      <div class="container"> 
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">Jericho</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
          <?php include 'navbar.php'; ?>
        </ul>
      </div>
    </nav>
  </div>
</div>


		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>


		<!-- galeri -->
  <section id="gallery" class="gallery">
        <div class="container">
          <h3 class="center ligth">Gallery</h3>
          <div class="row">
          <?php $id = 1; ?>
				  <?php while($artikel = mysqli_fetch_assoc($query)) : ?>
                <div class="col m3 s12">
                  <img src="images/artikel/<?= $artikel['foto'] ?>" class="responsive-img materialboxed">
                </div>
            <?php $id++; ?>
				<?php endwhile; ?>
        </div>
        </div>
  </section>

				
				
			</div>
			
		</div>
		<?php require 'footer.php';?>