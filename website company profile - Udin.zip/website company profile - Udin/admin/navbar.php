<?php
require_once 'cek_session.php';
$base_url = "http://localhost/project2021/";
?>

<li class="nav-item">
                <a class="nav-link <?= $active == 'dashboard' ? 'active' : '' ?>" href="<?= $base_url ?>admin">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?= $base_url ?>admin/pengguna/index.php">
                  <span data-feather="file"></span>
                  Data User
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?= $active == 'bukutamu' ? 'active' : '' ?> " href="<?= $base_url ?>admin/pesan.php">
                  <span data-feather="users"></span>
                  Kotak Pesan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?= $active == 'about' ? 'active' : '' ?> " href="<?= $base_url ?>admin/about.php">
                  <span data-feather="bar-chart-2"></span>
                  About
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?= $active == 'artikel' ? 'active' : '' ?> " href="<?= $base_url ?>admin/artikel/index.php">
                  <span data-feather="layers"></span>
                  Artikel
                </a>
              </li>
			  <li class="nav-item">
                <a class="nav-link <?= $active == 'detail-artikel' ? 'active' : '' ?> " href="<?= $base_url ?>admin/katArtikel/index.php">
                  <span data-feather="layers"></span>
                  Kategori Artikel
                </a>
              </li>
			  <li class="nav-item">
                <a class="nav-link" href="../">
                  <span data-feather="layers"></span>
                  Lihat Web
                </a>
              </li>