<link rel="icon" href="img/g.png">     
                        <li class="nav-item">
                        <a class="nav-item nav-link navlink <?= $aktif == 'home' ? 'active' : '' ?>" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-item nav-link navlink <?= $aktif == 'galeri' ? 'active' : '' ?>" href="galeri.php">Gallery</a>
                        </li>
                         <li class="nav-item">
                        <a class="nav-item nav-link navlink <?= $aktif == 'artikel' ? 'active' : '' ?>" href="artikel.php">News</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-item nav-link navlink <?= $aktif == 'produk' ? 'active' : '' ?>" href="produk.php">Product</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-item nav-link navlink <?= $aktif == 'about' ? 'active' : '' ?>" href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-item nav-link navlink <?= $aktif == 'kontak' ? 'active' : '' ?>" href="kontak.php">Contact</a>
                        </li>
         
