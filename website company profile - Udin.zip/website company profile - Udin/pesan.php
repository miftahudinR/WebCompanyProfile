<?php 

if(!isset($_POST['tambah'])) header('Location: kontak.php');

require_once 'koneksi.php';

$nama = mysqli_real_escape_string($koneksi, isset($_POST['nama']) ? $_POST['nama'] : '');
$email = mysqli_real_escape_string($koneksi, isset($_POST['email']) ? $_POST['email'] : '');
$notlp = mysqli_real_escape_string($koneksi, isset($_POST['notlp']) ? $_POST['notlp'] : '');
$pesan = mysqli_real_escape_string($koneksi, isset($_POST['pesan']) ? $_POST['pesan'] : '');

$query = mysqli_query($koneksi, "INSERT INTO tbl_pesan (nama, email, notlp, pesan) VALUES ('$nama', '$email', '$notlp', '$pesan')");
if($query){
	$_SESSION['sukses'] = 'Pesan Berhasil dikirim!';
	header('Location: kontak.php');
} else {
	$_SESSION['gagal'] = 'Pesan gagal dikirim!';
	header('Location: kontak.php');
}